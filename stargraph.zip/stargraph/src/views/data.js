
import { treemap, hierarchy } from 'd3-hierarchy'
import star from '@/assets/star.png'

const nodes = Array.from({ length: 8000 }, (v, k) => {
  return {
    id: `${k + 1}`,
    type: 'image-animate',
    img: star,
    size: Math.random() * 12 + 1,
    style: {
      // shadowOffsetX: 0,
      // shadowOffsetY: 0,
      // shadowColor: 'rgba(255, 0, 0, 0.4)',
      // shadowBlur: 10,
    },
    extra: {
      show: Math.random() < 0.1,
      type: `t${Math.round(Math.random() * 99 + 1)}`
    }
  }
})

const childrenMap = {}

nodes.forEach(v => {
  childrenMap[v.extra.type] ??= { name: v.extra.type, value: 0, nodes: [] }
  childrenMap[v.extra.type].value++
  childrenMap[v.extra.type].nodes.push(v)
})

const root = {
  name: 'root',
  children: Object.values(childrenMap)
}

const rects = treemap().size([1600, 900]).round(false).padding(0)(hierarchy(root).sum(v => v.value))
rects.children.forEach(v => {
  const item = childrenMap[v.data.name]
  const { x0, y0, x1, y1 } = v
  item.x0 = x0
  item.y0 = y0
  item.x1 = x1
  item.y1 = y1
  item.width = x1 - x0
  item.height = y1 - y0
})

nodes.forEach(v => {
  const item = childrenMap[v.extra.type]
  v.x = Math.random() * (item.width - v.size * 2) + item.x0 + v.size
  v.y = Math.random() * (item.height - v.size * 2) + item.y0 + v.size
})

export { nodes, childrenMap }