<template>
  <div class="home" ref="home"></div>
</template>

<script setup>
import G6 from '@antv/g6'
import { onMounted, ref } from 'vue'
import star from '@/assets/star.png'

import { nodes, childrenMap } from './data'

G6.registerNode('image-animate', {
  afterDraw(cfg, group) {
    // 获取该节点上的第一个图形
    const shape = group.get('children')[0];
    // 该图形的动画
    shape.animate(
      (ratio) => {
        return {
          opacity: ratio
        };
      },
      {
        // 动画重复
        duration: 1000,
        easing: 'easeQuadInOut',
      },
    ); // 一次动画持续的时长为 3000，动画效果为 'easeCubic'
  },
},
  'image',
);

console.log(childrenMap, 'childrenMap')

const home = ref()

function init() {
  const graph = new G6.Graph({
    container: home.value,
    width: 1600,
    height: 900,
    modes: {
      default: ['drag-canvas', 'drag-node', 'zoom-canvas'],
    },
    layout: false
  })

  // const nn = Object.values(childrenMap).map((v, k) => {
  //   return {
  //     id: `${v.name}`,
  //     type: 'rect',
  //     x: v.x0 + v.width / 2,
  //     y: v.y0 + v.height / 2,
  //     size: [v.width, v.height]
  //   }
  // }).concat(nodes.filter(v => v.extra.show))
  // console.log(nn, 'nn')

  graph.changeData({
    nodes: nodes.filter(v => v.extra.show)
  })
  setTimeout(() => {
    nodes.filter(v => v.extra.type === 't1' && !graph.findById(v.id)).forEach(v => graph.addItem('node', v))
    const hull = graph.createHull({
      id: 'selectArea',
      type: 'bubble',
      padding: 0,
      members: nodes.filter(v => v.extra.type === 't1').map(v => v.id)
    })

    graph.zoomTo(3, { x: 800, y: 450 }, true, {
      duration: 2000,
    });
    graph.focusItem(hull.members[0], true, {
      easing: 'easeCubic',
      duration: 2000,
    })

  }, 1000)

  // let index = 2
  // setInterval(() => {
  //   hull.members.push(`${index}`)
  //   hull.updateData(hull.members)
  //   index++
  // }, 1000)
}

onMounted(init)
</script>

<style scoped>
.home {
  width: 1600px;
  height: 900px;
  border: 1px solid red;
}
</style>